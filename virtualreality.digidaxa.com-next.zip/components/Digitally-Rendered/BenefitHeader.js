export default function BenefitHeader() {
  return (
    <div className="mx-auto text-center mb-16">
      <h4 className="font-semibold text-lg text-primary uppercase mb-4 tracking-widest lg:text-xl">Benefit</h4>
    </div>
  );
}
