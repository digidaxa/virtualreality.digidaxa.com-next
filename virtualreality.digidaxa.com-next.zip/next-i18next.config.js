module.exports = {
  i18n: {
    defaultLocale: 'id',
    locales: ['en', 'id'],
    localeDetection: false,
  },
};
